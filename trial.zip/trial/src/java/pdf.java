//below code is showing the pdf directly

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.itextpdf.layout.element.LineSeparator;
import com.itextpdf.text.Chunk;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.io.OutputStream;
//import java.io.PrintWriter;
import java.sql.ResultSetMetaData;


import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
//import com.itextpdf.layout.element.LineSeparator;
import com.itextpdf.text.Chunk;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import com.itextpdf.text.*;
//import com.itextpdf.text.pdf.*;

@WebServlet("/pdf")
public class pdf extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/pdf"); // Set content type to PDF
        response.setCharacterEncoding("UTF-8");

        try {
            Connection con = Dbconnection.connect();
            BufferedReader reader = request.getReader();
            StringBuilder jsonRequest = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                jsonRequest.append(line);
            }

            
            JsonObject jsonObject = new JsonParser().parse(jsonRequest.toString()).getAsJsonObject();
            String type = jsonObject.get("type").getAsString();
            
            // Fetch data from the MySQL table based on the 'type'
            String sql = "SELECT * FROM " + type;
            PreparedStatement statement = con.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();
            String pdfFileName = type + "_report.pdf"; // Desired PDF file name

            // Create a PdfWriter with the desired file name in the Downloads directory
            String downloadsFolderPath = System.getProperty("user.home") + "/Downloads/";
            String pdfFilePath = downloadsFolderPath + pdfFileName;

            // Create a FileOutputStream to save the PDF to the specified path
            FileOutputStream fileOutputStream = new FileOutputStream(pdfFilePath);

            Document document = new Document();
            PdfWriter writer = PdfWriter.getInstance(document, fileOutputStream);

            document.open();


            // Add an image to the PDF (adjust image path and dimensions as needed)
            Image image = Image.getInstance("D:\\jig clg\\MCA\\SEM 3\\trial\\trial\\pdf header.png");  // Replace with your image path
            image.scaleToFit(550, 550);  // Adjust dimensions as needed
            document.add(image);
            
            
            // Define fonts and styles
            BaseFont baseFont = BaseFont.createFont("Helvetica", "Cp1252", BaseFont.NOT_EMBEDDED);
            Font headingFont = new Font(baseFont, 16, Font.BOLD);
            Font subHeadingFont = new Font(baseFont, 14, Font.BOLD);
            Font normalFont = new Font(baseFont, 12);

            // Add a title (centered)
            Paragraph title = new Paragraph("PDF Report", headingFont);
            title.setAlignment(Paragraph.ALIGN_CENTER);
            document.add(title);

            // Add a subheading (centered)
            Paragraph subHeading = new Paragraph("Subtitle", subHeadingFont);
            subHeading.setAlignment(Paragraph.ALIGN_CENTER);
            document.add(subHeading);

            // Add a dummy address (left aligned)
            Paragraph address = new Paragraph();
            address.add(new Chunk("1234 Dummy St, ", normalFont));
            address.add(new Chunk("City, State, Country", normalFont));
            document.add(address);

            // Add a line break
            document.add(new Paragraph("\n"));


// Fetch column names dynamically
ResultSetMetaData metaData = resultSet.getMetaData();
int columnCount = metaData.getColumnCount();

// Create a table with the appropriate number of columns
PdfPTable table = new PdfPTable(columnCount);
table.setWidthPercentage(100);

// Initialize variables for the amount total and the index of the amount column
double totalAmount = 0.0;
int amountColumnIndex = 0;

// Add headers to the table
for (int i = 1; i <= columnCount; i++) {
    String columnName = metaData.getColumnName(i);

    if (columnName.equals("Amount")) {
        amountColumnIndex = i;  // Save the index of the amount column
    }

    // Create a Phrase with line spacing for the header
    Phrase headerPhrase = new Phrase(columnName + "\n", new Font(Font.FontFamily.HELVETICA, 11, Font.BOLD));
    headerPhrase.setLeading(0.5f);

    PdfPCell headerCell = new PdfPCell(headerPhrase);
    headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);  // Center align the header
    table.addCell(headerCell);
}

// Add data to the table in the PDF document
while (resultSet.next()) {
    for (int i = 1; i <= columnCount; i++) {
        String columnValue = resultSet.getString(i);

        if (i == amountColumnIndex) {
            double amount = Double.parseDouble(columnValue);
            totalAmount += amount;  // Sum up the amount
        }

        PdfPCell dataCell = new PdfPCell(new Phrase(columnValue));
        table.addCell(dataCell);
    }
}

// Add a row for the total amount
for (int i = 1; i <= columnCount; i++) 
{
    if (i == amountColumnIndex-1) 
    {
        table.addCell(new PdfPCell(new Phrase("Total Amount:", new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD))));
    }else if(i == amountColumnIndex) 
    {
        table.addCell(new PdfPCell(new Phrase(String.format("%.2f", totalAmount), new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL))));
    }else
    {
        table.addCell(new PdfPCell(new Phrase("")));
    }
}

// Add the table to the document
document.add(table);


            document.close();
            writer.close();
            fileOutputStream.close();

            // Provide a direct link to the user for downloading the PDF
            response.setHeader("Content-Disposition", "attachment;filename=" + pdfFileName);

            // Read the PDF file and write it to the response's output stream
            FileInputStream fis = new FileInputStream(pdfFilePath);
            byte[] buffer = new byte[1024];
            int bytesRead;
            OutputStream os = response.getOutputStream();
            while ((bytesRead = fis.read(buffer)) != -1) {
                os.write(buffer, 0, bytesRead);
            }
            os.flush();
            os.close();
            fis.close();

        } catch (SQLException | DocumentException e) {
            e.printStackTrace();
            response.getWriter().println("Failed to generate PDF.");
        }
    }
}




// below code is about sending the pdf location

//import com.google.gson.JsonObject;
//import com.google.gson.JsonParser;
//import com.itextpdf.text.*;
//import com.itextpdf.text.pdf.PdfPCell;
//import com.itextpdf.text.pdf.PdfPTable;
//import com.itextpdf.text.pdf.PdfWriter;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.io.*;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.ResultSetMetaData;
//import java.sql.SQLException;
//
//@WebServlet("/pdf")
//public class pdf extends HttpServlet {
//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//        throws ServletException, IOException {
//    response.setContentType("application/json"); // Set content type to JSON
//    response.setCharacterEncoding("UTF-8");
//
//    try {
//        Connection con = Dbconnection.connect();
//        BufferedReader reader = request.getReader();
//        StringBuilder jsonRequest = new StringBuilder();
//        String line;
//        while ((line = reader.readLine()) != null) {
//            jsonRequest.append(line);
//        }
//
//        JsonObject jsonObject = new JsonParser().parse(jsonRequest.toString()).getAsJsonObject();
//        String type = jsonObject.get("type").getAsString();
//
//        // Fetch data from the MySQL table based on the 'type'
//        String sql = "SELECT * FROM " + type;
//        PreparedStatement statement = con.prepareStatement(sql);
//        ResultSet resultSet = statement.executeQuery();
//        String pdfFileName = type + "_report.pdf"; // Desired PDF file name
//
//        // Create a PdfWriter with the desired file name in the Downloads directory
//        String downloadsFolderPath = System.getProperty("user.home") + "/Downloads/";
//        String pdfFilePath = downloadsFolderPath + pdfFileName;
//
//        // Create a FileOutputStream to save the PDF to the specified path
//        FileOutputStream fileOutputStream = new FileOutputStream(pdfFilePath);
//
//        Document document = new Document();
//        PdfWriter writer = PdfWriter.getInstance(document, fileOutputStream);
//
//        document.open();
//        // Add an image to the PDF (adjust image path and dimensions as needed)
//        Image image = Image.getInstance("D:\\jig clg\\MCA\\SEM 3\\trial\\trial\\pdf header.png");  // Replace with your image path
//        image.scaleToFit(550, 550);  // Adjust dimensions as needed
//        document.add(image);
//
//        // Fetch column names dynamically
//        ResultSetMetaData metaData = resultSet.getMetaData();
//        int columnCount = metaData.getColumnCount();
//
//        // Create a table with the appropriate number of columns
//        PdfPTable table = new PdfPTable(columnCount);
//        table.setWidthPercentage(100);
//
//        // ... (rest of the table creation code)
//
//        // Add the table to the document
//        document.add(table);
//
//        document.close();
//        writer.close();
//        fileOutputStream.close();
//
//        // Provide a direct link to the user for downloading the PDF
//        response.setHeader("Content-Disposition", "attachment;filename=" + pdfFileName);
//
//        // Read the PDF file and write it to the response's output stream
//        FileInputStream fis = new FileInputStream(pdfFilePath);
//        byte[] buffer = new byte[1024];
//        int bytesRead;
//        OutputStream os = response.getOutputStream();
//        while ((bytesRead = fis.read(buffer)) != -1) {
//            os.write(buffer, 0, bytesRead);
//        }
//        os.flush();
//        os.close();
//        fis.close();
//
//        // Send the PDF path in the JSON response
//        JsonObject jsonResponse = new JsonObject();
//        jsonResponse.addProperty("pdfPath", pdfFilePath);
//        PrintWriter out = response.getWriter();
//        out.print(jsonResponse.toString());
//        out.flush();
//
//    } catch (SQLException | DocumentException e) {
//        e.printStackTrace();
//        response.getWriter().println("Failed to generate PDF.");
//    }
//}
//}
