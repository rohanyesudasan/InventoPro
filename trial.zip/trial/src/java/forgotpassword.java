import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/forgotpassword"})
public class forgotpassword extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    
}

private void updatePassword(String userEmail, String newPassword) throws ServletException, IOException {
    try (Connection con = Dbconnection.connect()) {
        // TODO: Implement the SQL update statement to update the user's password
        String sql = "UPDATE users SET Password = ? WHERE Email = ?";
        PreparedStatement preparedStatement = con.prepareStatement(sql);
        preparedStatement.setString(1, newPassword);
        preparedStatement.setString(2, userEmail);

        // Execute the update query
        int rowsUpdated = preparedStatement.executeUpdate();

        if (rowsUpdated > 0) {
            System.out.println("Password updated successfully.");
        } else {
            System.out.println("Password update failed.");
        }
    } catch (SQLException e) {
        // Handle any SQL errors
        e.printStackTrace();
    }
}


    private String fetchUserEmail(String phoneNumber) {
        try (Connection con = Dbconnection.connect()) {
            String sql = "SELECT Email FROM users WHERE Phone_Number = ?";
            PreparedStatement preparedStatement = con.prepareStatement(sql);
            preparedStatement.setString(1, phoneNumber);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getString("Email");
            } else {
                System.out.println("No user found for phone number: " + phoneNumber);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ServletException | IOException ex) {
            Logger.getLogger(forgotpassword.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }


    private String generateRandomPassword() {
        // Implement your logic to generate a random secure password
        return "RandomGeneratedPassword123";
    }

    private static final String FROM_EMAIL = "keyloggerfor111@gmail.com";
    private static final String EMAIL_PASSWORD = "cpldbrqrhqbrivli";
    
   private void sendEmail(String toEmail, String name, String newPassword) {
    String host = "smtp.gmail.com";
    String port = "587";
    String username = FROM_EMAIL;
    String password = EMAIL_PASSWORD;

    Properties properties = new Properties();
    properties.put("mail.smtp.host", host);
    properties.put("mail.smtp.port", port);
    properties.put("mail.smtp.auth", "true");
    properties.put("mail.smtp.starttls.enable", "true");

    Session session = Session.getInstance(properties, new Authenticator() {
        @Override
        protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(username, password);
        }
    });

    try {
            String subject = "Password Reset";
            String body = "<html><body>" +
                "<h2>[Product Name]</h2>" +
                "<p>Hi " + name + ",</p>" +
                "<p>You recently requested to reset your password for your ShelfIq account. " +
                "Your new password is:</p>" +
                "<h1 style='font-size:24px;'>" + newPassword + "</h1>" +
                "<p>This password is only valid for the next 24 hours.</p>" +
                "contact support if you have questions.</p>" +
                "<p>Thanks,<br>The ShelfIq Team</p>" +
                "<p>If you’re having trouble with the password, please contact support.</p>" +
                "</body></html>";
        
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(username));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
        message.setSubject(subject);
        message.setContent(body, "text/html");

        Transport.send(message);
        System.out.println("Email sent successfully to: " + toEmail);
    } catch (MessagingException e) {
        e.printStackTrace();
        System.err.println("Failed to send email.");
    }

}


    
@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    response.setContentType("application/json");
    response.setCharacterEncoding("UTF-8");
    PrintWriter out = response.getWriter();

    JsonResponse jsonResponse = new JsonResponse();

    try {
        // Parse the JSON data from the request body
        BufferedReader reader = request.getReader();
        StringBuilder jsonBuilder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonBuilder.append(line);
        }
        String jsonData = jsonBuilder.toString();

        // Parse the JSON data using Gson
        JsonParser parser = new JsonParser();
        JsonObject json = parser.parse(jsonData).getAsJsonObject();

        // Extract the phone number from the JSON object
        String phoneNumber = json.get("phoneNumber").getAsString();

        // Debug: Print the received phone number
        System.out.println("Received phone number: " + phoneNumber);

        // Fetch the user's email based on the provided phone number from the database
        String userEmail = fetchUserEmail(phoneNumber);

        if (userEmail != null) {
            // Generate a new password
            String newPassword = generateRandomPassword();

            // Update the user's password in your database using the newPassword
            updatePassword(userEmail, newPassword);

            // Send the new password to the user's email
            sendEmail(userEmail, phoneNumber, newPassword);

            jsonResponse.setStatus(true);
            jsonResponse.setMessage("New password sent to the registered email address. Please check the Spam mail folder to get the Updated Password");
        } else {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("No user found for the provided phone number.");
        }
    } catch (Exception e) {
        jsonResponse.setStatus(false);
        jsonResponse.setMessage("Error: " + e.getMessage());
    }

    out.println(new Gson().toJson(jsonResponse));
}

@Override
protected void doPut(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    response.setContentType("application/json");
    response.setCharacterEncoding("UTF-8");
    JsonResponse jsonResponse = new JsonResponse();

    try (Connection con = Dbconnection.connect()) {
        BufferedReader reader = request.getReader();
        StringBuilder jsonRequest = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonRequest.append(line);
        }

        JsonObject jsonObject = new JsonParser().parse(jsonRequest.toString()).getAsJsonObject();
        String Phone_Number = jsonObject.get("Phone_Number").getAsString();
        String newPassword = jsonObject.get("newPassword").getAsString();

        String updatePasswordSQL = "UPDATE users SET Password = ? WHERE Phone_Number = ?";
        PreparedStatement stmt = con.prepareStatement(updatePasswordSQL);
        stmt.setString(1, newPassword);
        stmt.setString(2, Phone_Number);
        int updatedRows = stmt.executeUpdate();

        if (updatedRows > 0) {
            jsonResponse.setStatus(true);
            jsonResponse.setMessage("Password Updated.");
        } else {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("Error In Updating Password.");
        }
    } catch (Exception e) {
        jsonResponse.setStatus(false);
        jsonResponse.setMessage("Error: " + e.getMessage());
    }

    PrintWriter out = response.getWriter();
    out.println(new Gson().toJson(jsonResponse));
}

}