import com.mysql.cj.jdbc.result.ResultSetMetaData;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author jigar
 */
@WebServlet(urlPatterns = {"/insertproduct"})
public class insertpurchase extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (Connection con = Dbconnection.connect()) {
            String query = "SELECT s.ID AS Supplier_ID, s.Name AS Supplier_Name, p.ID AS Product_ID, p.Product_Name\n" +
                    "FROM SUPPLIER AS s\n" +
                    "JOIN PRODUCT AS p ON s.ID = p.Shelf_ID";
            PreparedStatement stmt = con.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            JSONArray jsonArray = new JSONArray();
            while (rs.next()) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("Supplier_ID", rs.getInt("Supplier_ID"));
                jsonObject.put("Supplier_Name", rs.getString("Supplier_Name"));
                jsonObject.put("Product_ID", rs.getInt("Product_ID"));
                jsonObject.put("Product_Name", rs.getString("Product_Name"));
                jsonArray.put(jsonObject);
            }

            // Sending the JSON array as the response
            out.println(jsonArray.toString());
        } catch (Exception e) {
            out.println(e);
        }
    }
}

