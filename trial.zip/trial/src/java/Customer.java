import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import com.google.gson.*;
import java.io.BufferedReader;
import javax.servlet.annotation.WebServlet;
import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet(urlPatterns = {"/Customer"})
public class Customer extends HttpServlet {

 @Override
protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    PrintWriter out = response.getWriter();
    try (Connection con = Dbconnection.connect()) {

        String getproduct = "SELECT * FROM customer";
        PreparedStatement stmt = con.prepareStatement(getproduct);
        ResultSet rs = stmt.executeQuery();
        JSONArray json = new JSONArray();
        com.mysql.cj.jdbc.result.ResultSetMetaData rsmd = (com.mysql.cj.jdbc.result.ResultSetMetaData) rs.getMetaData();

        while (rs.next()) {
            int numColumns = rsmd.getColumnCount();
            JSONObject obj = new JSONObject();

            for (int i = 1; i <= numColumns; i++) {
                String column_name = rsmd.getColumnName(i);
                if (rsmd.getColumnType(i) == java.sql.Types.ARRAY) {
                    obj.put(column_name, rs.getArray(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.BIGINT) {
                    obj.put(column_name, rs.getInt(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.BOOLEAN) {
                    obj.put(column_name, rs.getBoolean(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.BLOB) {
                    obj.put(column_name, rs.getBlob(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.DOUBLE) {
                    obj.put(column_name, rs.getDouble(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.FLOAT) {
                    obj.put(column_name, rs.getFloat(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.INTEGER) {
                    obj.put(column_name, rs.getInt(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.NVARCHAR) {
                    obj.put(column_name, rs.getNString(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.VARCHAR) {
                    obj.put(column_name, rs.getString(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.TINYINT) {
                    obj.put(column_name, rs.getInt(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.SMALLINT) {
                    obj.put(column_name, rs.getInt(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.DATE) {
                    obj.put(column_name, rs.getDate(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.TIMESTAMP) {
                    obj.put(column_name, rs.getTimestamp(column_name));
                } else {
                    obj.put(column_name, rs.getObject(column_name));
                }
            }
            json.put(obj);
        }
        // Setting the response content type to JSON
        response.setContentType("application/json");
        out.println(json.toString());

    } catch (Exception e) {
        out.println(e);
    }
}

    
    @Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException 
{
    response.setContentType("application/json");
    response.setCharacterEncoding("UTF-8");
    
    JsonResponse jsonResponse = new JsonResponse();
    
    try (Connection con = Dbconnection.connect()) {
        BufferedReader reader = request.getReader();
        StringBuilder jsonRequest = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonRequest.append(line);
        }

        JsonObject jsonObject = new JsonParser().parse(jsonRequest.toString()).getAsJsonObject();
        String Name = jsonObject.get("Name").getAsString();
        String Phone_Number = jsonObject.get("Phone_Number").getAsString();
        String Email = jsonObject.get("Email").getAsString();
        String Address = jsonObject.get("Address").getAsString();

        String sql = "INSERT INTO customer (Name, Phone_Number,Email,Address) VALUES (?, ?, ?, ?)";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, Name);
        stmt.setString(2, Phone_Number);
        stmt.setString(3, Email);
        stmt.setString(4, Address);
        int count = stmt.executeUpdate();

        if (count > 0) {
            jsonResponse.setStatus(true);
            jsonResponse.setMessage("Customer Registered");
        } else {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("Customer Not REGISTERED");
        }
    } catch (Exception e) {
        jsonResponse.setStatus(false);
        jsonResponse.setMessage("Error: " + e.getMessage());
    }

    PrintWriter out = response.getWriter();
    out.println(new Gson().toJson(jsonResponse));
}
    
    @Override
protected void doPut(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException 
{
    response.setContentType("application/json");
    response.setCharacterEncoding("UTF-8");
    JsonResponse jsonResponse = new JsonResponse();
    PrintWriter out = response.getWriter();

    try (Connection con = Dbconnection.connect()) {
        BufferedReader reader = request.getReader();
        StringBuilder jsonRequest = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonRequest.append(line);
        }

        JsonObject jsonObject = new JsonParser().parse(jsonRequest.toString()).getAsJsonObject();
        int ID = jsonObject.get("ID").getAsInt();
        String Name = jsonObject.get("Name").getAsString();
        String Phone_Number = jsonObject.get("Phone_Number").getAsString();
        String Email = jsonObject.get("Email").getAsString();
        String Address = jsonObject.get("Address").getAsString();

        String updateCustomerProfile = "UPDATE customer SET Name = ?, Phone_Number = ?, Email = ?, Address = ? WHERE ID = ?";
        PreparedStatement stmt = con.prepareStatement(updateCustomerProfile);
        stmt.setString(1, Name);
        stmt.setString(2, Phone_Number);
        stmt.setString(3, Email);
        stmt.setString(4, Address);
        stmt.setInt(5,ID);
        
        int count = stmt.executeUpdate();
        
        if (count > 0) {
            jsonResponse.setStatus(true);
            jsonResponse.setMessage("Customer Profile Updated.");
        } else {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("Error In Updating Customer Profile.");
        }
    } catch (Exception e) {
        out.println(e);
    }
    out.println(new Gson().toJson(jsonResponse));
}

@Override
protected void doDelete(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException 
{
    PrintWriter out = response.getWriter();
    JsonResponse jsonResponse = new JsonResponse();

    try {
        BufferedReader reader = request.getReader();
        StringBuilder jsonRequest = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonRequest.append(line);
        }

        JsonObject jsonObject = new JsonParser().parse(jsonRequest.toString()).getAsJsonObject();
        String ID = jsonObject.get("ID").getAsString();

        Connection con = Dbconnection.connect();
        String deleteProfile = "DELETE FROM customer WHERE ID = ?";
        PreparedStatement stmt = con.prepareStatement(deleteProfile);
        stmt.setString(1, ID);

        int check = stmt.executeUpdate();

        if (check > 0) {
            jsonResponse.setStatus(true);
            jsonResponse.setMessage("Customer Profile Removed.");
        } else {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("Error In Deleting Customer Profile.");
        }
    } catch (IOException | SQLException e) {
        out.println(e);
    }
    out.println(new Gson().toJson(jsonResponse));
}

}
