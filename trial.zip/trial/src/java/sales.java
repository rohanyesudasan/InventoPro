import com.google.gson.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.*;

@WebServlet(urlPatterns = {"/sales"})
public class sales extends HttpServlet {
    
    @Override
protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    PrintWriter out = response.getWriter();
    try (Connection con = Dbconnection.connect()) {

 String getSales = "SELECT  s.Quantity,s.Amount,s.Date,c.Name,pr.Product_Name FROM " +
                                            " sales s " +
                                            "JOIN" +
                                            " customer c ON s.Customer_ID = c.ID\n" +
                                            "JOIN" +
                                            " product pr ON s.Product_ID = pr.ID;";
        PreparedStatement stmt = con.prepareStatement(getSales);
        ResultSet rs = stmt.executeQuery();
        JSONArray json = new JSONArray();
        ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();

        while (rs.next()) {
            int numColumns = rsmd.getColumnCount();
            JSONObject obj = new JSONObject();

            for (int i = 1; i <= numColumns; i++) {
                String column_name = rsmd.getColumnName(i);
                if (rsmd.getColumnType(i) == java.sql.Types.ARRAY) {
                    obj.put(column_name, rs.getArray(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.BIGINT) {
                    obj.put(column_name, rs.getInt(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.BOOLEAN) {
                    obj.put(column_name, rs.getBoolean(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.BLOB) {
                    obj.put(column_name, rs.getBlob(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.DOUBLE) {
                    obj.put(column_name, rs.getDouble(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.FLOAT) {
                    obj.put(column_name, rs.getFloat(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.INTEGER) {
                    obj.put(column_name, rs.getInt(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.NVARCHAR) {
                    obj.put(column_name, rs.getNString(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.VARCHAR) {
                    obj.put(column_name, rs.getString(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.TINYINT) {
                    obj.put(column_name, rs.getInt(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.SMALLINT) {
                    obj.put(column_name, rs.getInt(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.DATE) {
                    obj.put(column_name, rs.getDate(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.TIMESTAMP) {
                    obj.put(column_name, rs.getTimestamp(column_name));
                } else {
                    obj.put(column_name, rs.getObject(column_name));
                }
            }
            json.put(obj);
        }
        // Setting the response content type to JSON
        response.setContentType("application/json");
        out.println(json.toString());

    } catch (Exception e) {
        out.println(e);
    }
}

    
@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    response.setContentType("application/json");
    response.setCharacterEncoding("UTF-8");
    PrintWriter out = response.getWriter();

    JsonResponse jsonResponse = new JsonResponse();

    try (Connection con = Dbconnection.connect()) {
        // Read the JSON data from the request input stream
        BufferedReader reader = request.getReader();
        StringBuilder jsonData = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonData.append(line);
        }

        // Parse the JSON data
        JsonObject jsonObject = new JsonParser().parse(jsonData.toString()).getAsJsonObject();

        int productId = jsonObject.get("Product_ID").getAsInt();
        int customerId = jsonObject.get("Customer_ID").getAsInt();
        int quantity = jsonObject.get("Quantity").getAsInt();
        float amount = jsonObject.get("Amount").getAsFloat();

        String insertSales = "INSERT INTO SALES (Customer_ID, Product_ID, Quantity, Amount, Date) " +
                "VALUES (?, ?, ?, ?, CURRENT_DATE)";

        PreparedStatement stmt = con.prepareStatement(insertSales);
        stmt.setInt(1, customerId);
        stmt.setInt(2, productId);
        stmt.setInt(3, quantity);
        stmt.setFloat(4, amount);

        int count = stmt.executeUpdate();

        if (count > 0) {
            // Update the product's quantity by subtracting the sold quantity
            String updateProductQuantityQuery = "UPDATE PRODUCT SET Quantity = Quantity - ? WHERE ID = ?";
            PreparedStatement updateProductStmt = con.prepareStatement(updateProductQuantityQuery);
            updateProductStmt.setInt(1, quantity);
            updateProductStmt.setInt(2, productId);
            updateProductStmt.executeUpdate();

            jsonResponse.setStatus(true);
            jsonResponse.setMessage("Sales Record Inserted");
        } else {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("Oops, there is an error inserting the sales record...");
        }
    } catch (Exception e) {
        jsonResponse.setStatus(false);
        jsonResponse.setMessage("Error: " + e.getMessage());
    }
    out.println(new Gson().toJson(jsonResponse));
}




@Override
protected void doPut(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    PrintWriter out = response.getWriter();
    response.setContentType("application/json");
    response.setCharacterEncoding("UTF-8");
    JsonResponse jsonResponse = new JsonResponse();

    try (Connection con = Dbconnection.connect()) {
        // Read the JSON data from the request input stream
        BufferedReader reader = request.getReader();
        StringBuilder jsonData = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonData.append(line);
        }

        // Parse the JSON data
        JsonObject jsonObject = new JsonParser().parse(jsonData.toString()).getAsJsonObject();

        int ID = jsonObject.get("ID").getAsInt();
        int customerID = jsonObject.get("Customer_ID").getAsInt();
        int productID = jsonObject.get("Product_ID").getAsInt();
        int quantity = jsonObject.get("Quantity").getAsInt();
        float amount = jsonObject.get("Amount").getAsFloat();

        String updateQuery = "UPDATE SALES SET Customer_ID=?, Product_ID=?, Quantity=?, Amount=? WHERE ID=?";
        PreparedStatement stmt = con.prepareStatement(updateQuery);
        stmt.setInt(1, customerID);
        stmt.setInt(2, productID);
        stmt.setInt(3, quantity);
        stmt.setFloat(4, amount);
        stmt.setInt(5, ID);

        int check = stmt.executeUpdate();

        if (check > 0) {
            jsonResponse.setStatus(true);
            jsonResponse.setMessage("Sales Record Updated.");
        } else {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("Error In Updating Sales Record.");
        }

    } catch (IOException | NumberFormatException | SQLException e) {
        jsonResponse.setStatus(false);
        jsonResponse.setMessage("Error: " + e.getMessage());
    }

    out.println(new Gson().toJson(jsonResponse));
}


@Override
protected void doDelete(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    PrintWriter out = response.getWriter();
    response.setContentType("application/json");
    response.setCharacterEncoding("UTF-8");
    JsonResponse jsonResponse = new JsonResponse();

    try (Connection con = Dbconnection.connect()) {
        BufferedReader reader = request.getReader();
        StringBuilder jsonData = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonData.append(line);
        }

        // Parse the JSON data
        JsonObject jsonObject = new JsonParser().parse(jsonData.toString()).getAsJsonObject();

        int ID = jsonObject.get("ID").getAsInt();

        String deleteQuery = "DELETE FROM SALES WHERE ID = ?";
        PreparedStatement stmt = con.prepareStatement(deleteQuery);
        stmt.setInt(1, ID);

        int check = stmt.executeUpdate();

        if (check > 0) {
            jsonResponse.setStatus(true);
            jsonResponse.setMessage("Sales Record Removed.");
        } else {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("Error In Deleting Sales Record.");
        }

    } catch (NumberFormatException | SQLException e) {
        jsonResponse.setStatus(false);
        jsonResponse.setMessage("Error: " + e.getMessage());
        e.printStackTrace(); // Print the exception details
    }

    // Log the jsonResponse before sending it
    System.out.println("Response: " + new Gson().toJson(jsonResponse));

    out.println(new Gson().toJson(jsonResponse));
}

    
}