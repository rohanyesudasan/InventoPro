import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import com.google.gson.*;
import java.io.BufferedReader;
import javax.servlet.annotation.WebServlet;

@WebServlet(urlPatterns = {"/login"})
public class login extends HttpServlet {
  
   @Override
   protected void doPost(HttpServletRequest request, HttpServletResponse response)
           throws ServletException, IOException {
       response.setContentType("application/json");
       response.setCharacterEncoding("UTF-8");

       JsonResponse jsonResponse = new JsonResponse();
       PrintWriter out = response.getWriter();

       try (Connection con = Dbconnection.connect()) {
           // Read JSON data from the request's input stream
           BufferedReader reader = request.getReader();
           StringBuilder jsonRequest = new StringBuilder();
           String line;
           while ((line = reader.readLine()) != null) {
               jsonRequest.append(line);
           }

           // Parse the JSON data
           JsonObject jsonObject = new JsonParser().parse(jsonRequest.toString()).getAsJsonObject();
           String email = jsonObject.get("Email").getAsString();
           String password = jsonObject.get("Password").getAsString();

           String sql = "SELECT * FROM users WHERE Email = ? AND Password = ?";
           PreparedStatement stmt = con.prepareStatement(sql);
           stmt.setString(1, email);
           stmt.setString(2, password);
           ResultSet resultSet = stmt.executeQuery();
           if (resultSet.next()) {
               String username = resultSet.getString("Name"); 
               String type = resultSet.getString("Type");
               jsonResponse.setStatus(true);
               jsonResponse.setMessage("Logged in" +" " +username); 
               jsonResponse.setType(type);
               jsonResponse.setUsername(username);  // Set the username in the response
           } else {
               jsonResponse.setStatus(false);
               jsonResponse.setMessage("Wrong Username or Password");
           }
       } catch (SQLException e) {
           jsonResponse.setStatus(false);
           jsonResponse.setMessage("Error: " + e.getMessage());
           out.println(e);
       }
       out.println(new Gson().toJson(jsonResponse));
   }
}
