/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.google.gson.*;
import com.mysql.cj.jdbc.result.ResultSetMetaData;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author jigar
 */
@WebServlet(urlPatterns = {"/product"})
public class product extends HttpServlet {
    

    @Override
protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    PrintWriter out = response.getWriter();
    try (Connection con = Dbconnection.connect()) {

        String getproduct = "SELECT * FROM product";
        PreparedStatement stmt = con.prepareStatement(getproduct);
        ResultSet rs = stmt.executeQuery();
        JSONArray json = new JSONArray();
        ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();

        while (rs.next()) {
            int numColumns = rsmd.getColumnCount();
            JSONObject obj = new JSONObject();

            for (int i = 1; i <= numColumns; i++) {
                String column_name = rsmd.getColumnName(i);
                if (rsmd.getColumnType(i) == java.sql.Types.ARRAY) {
                    obj.put(column_name, rs.getArray(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.BIGINT) {
                    obj.put(column_name, rs.getInt(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.BOOLEAN) {
                    obj.put(column_name, rs.getBoolean(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.BLOB) {
                    obj.put(column_name, rs.getBlob(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.DOUBLE) {
                    obj.put(column_name, rs.getDouble(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.FLOAT) {
                    obj.put(column_name, rs.getFloat(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.INTEGER) {
                    obj.put(column_name, rs.getInt(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.NVARCHAR) {
                    obj.put(column_name, rs.getNString(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.VARCHAR) {
                    obj.put(column_name, rs.getString(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.TINYINT) {
                    obj.put(column_name, rs.getInt(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.SMALLINT) {
                    obj.put(column_name, rs.getInt(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.DATE) {
                    obj.put(column_name, rs.getDate(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.TIMESTAMP) {
                    obj.put(column_name, rs.getTimestamp(column_name));
                } else {
                    obj.put(column_name, rs.getObject(column_name));
                }
            }
            json.put(obj);
        }
        // Setting the response content type to JSON
        response.setContentType("application/json");
        out.println(json.toString());

    } catch (Exception e) {
        out.println(e);
    }
}

@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        
    response.setContentType("application/json");
    response.setCharacterEncoding("UTF-8");
    PrintWriter out = response.getWriter();
    
    JsonResponse jsonResponse = new JsonResponse();
    
    try (Connection con = Dbconnection.connect()) {
        // Read the JSON data from the request input stream
        BufferedReader reader = request.getReader();
        StringBuilder jsonData = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonData.append(line);
        }

        // Parse the JSON data
        JsonObject jsonObject = new JsonParser().parse(jsonData.toString()).getAsJsonObject();
        
        String Product_Name = jsonObject.get("Product_Name").getAsString();
        String Product_Description = jsonObject.get("Product_Description").getAsString();
        int Quantity = jsonObject.get("Quantity").getAsInt();
        float Selling_Price = jsonObject.get("Selling_Price").getAsFloat();

        String sql = "INSERT INTO product (Product_Name, Product_Description, Quantity, Selling_Price) VALUES (?, ?, ?, ?)";
        
        PreparedStatement stmt = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
        stmt.setString(1, Product_Name);
        stmt.setString(2, Product_Description);
        stmt.setInt(3, Quantity);
        stmt.setFloat(4, Selling_Price);
        int count = stmt.executeUpdate();
        
        if (count > 0) {
            // Retrieve the generated ID for the new product
            ResultSet generatedKeys = stmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                int generatedID = generatedKeys.getInt(1);
                // Update the Shelf_ID with the generated ID for the new product
                String updateShelfIDSQL = "UPDATE product SET Shelf_ID = ? WHERE ID = ?";
                PreparedStatement updateStmt = con.prepareStatement(updateShelfIDSQL);
                updateStmt.setInt(1, generatedID);
                updateStmt.setInt(2, generatedID);
                updateStmt.executeUpdate();
                
                jsonResponse.setStatus(true);
                jsonResponse.setMessage("Product Inserted");
            } else {
                jsonResponse.setStatus(false);
                jsonResponse.setMessage("Failed to retrieve the generated ID.");
            }
        } else {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("Oops, there is some error inserting the product...");
        }    
    } catch (Exception e) {
        jsonResponse.setStatus(false);
        jsonResponse.setMessage("Error: " + e.getMessage());
    }
    out.println(new Gson().toJson(jsonResponse));
}

@Override
protected void doPut(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    PrintWriter out = response.getWriter();
    response.setContentType("application/json");
    response.setCharacterEncoding("UTF-8"); 
    JsonResponse jsonResponse = new JsonResponse();

    try (Connection con = Dbconnection.connect()) {
        // Read the JSON data from the request input stream
        BufferedReader reader = request.getReader();
        StringBuilder jsonData = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonData.append(line);
        }

        // Parse the JSON data
        JsonObject jsonObject = new JsonParser().parse(jsonData.toString()).getAsJsonObject();

        int ID = jsonObject.get("ID").getAsInt();
        String Product_Name = jsonObject.get("Product_Name").getAsString();
        String Product_Description = jsonObject.get("Product_Description").getAsString();
        int Quantity = jsonObject.get("Quantity").getAsInt();
        float Selling_Price = jsonObject.get("Selling_Price").getAsFloat();

        String updateQuery = "UPDATE product SET Product_Name=?, Product_Description=?, Quantity=?, Selling_Price=? WHERE ID=?";
        PreparedStatement stmt = con.prepareStatement(updateQuery);
        stmt.setString(1, Product_Name);
        stmt.setString(2, Product_Description);
        stmt.setInt(3, Quantity);
        stmt.setFloat(4, Selling_Price);
        stmt.setInt(5, ID);

        int check = stmt.executeUpdate();

        if (check > 0) {
            jsonResponse.setStatus(true);
            jsonResponse.setMessage("Product Updated.");
        } else {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("Error In Updating product.");
        }

    } catch (IOException | NumberFormatException | SQLException e) {
        jsonResponse.setStatus(false);
        jsonResponse.setMessage("Error: " + e.getMessage());
    }

    out.println(new Gson().toJson(jsonResponse));
}

protected void doDelete(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    PrintWriter out = response.getWriter();
    response.setContentType("application/json");
    response.setCharacterEncoding("UTF-8");
    JsonResponse jsonResponse = new JsonResponse();

    try (Connection con = Dbconnection.connect()) {
        BufferedReader reader = request.getReader();
        StringBuilder jsonData = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonData.append(line);
        }

        // Parse the JSON data
        JsonObject jsonObject = new JsonParser().parse(jsonData.toString()).getAsJsonObject();

        int ID = jsonObject.get("ID").getAsInt();

        String deleteQuery = "DELETE FROM product WHERE ID = ?";
        PreparedStatement stmt = con.prepareStatement(deleteQuery);
        stmt.setInt(1, ID);

        int check = stmt.executeUpdate();

        if (check > 0) {
            jsonResponse.setStatus(true);
            jsonResponse.setMessage("Product Removed.");
        } else {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("Error In deleting product. Product may not exist or an error occurred.");
        }

    } catch (NumberFormatException | SQLException e) {
        jsonResponse.setStatus(false);
        jsonResponse.setMessage("Error: " + e.getMessage());
        e.printStackTrace(); // Print the exception details
    }

    // Log the jsonResponse before sending it
    System.out.println("Response: " + new Gson().toJson(jsonResponse));

    out.println(new Gson().toJson(jsonResponse));
}

@Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
