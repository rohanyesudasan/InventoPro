
import com.google.gson.*;
import com.mysql.cj.jdbc.result.ResultSetMetaData;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author jigar
 */
@WebServlet(urlPatterns = {"/purchase"})
public class purchase extends HttpServlet {
    
private int getProductIdFromProductName(String productName, Connection con) throws SQLException {
            String getProductIDQuery = "SELECT Product_ID FROM PRODUCT WHERE Product_Name = ?";
            try (PreparedStatement preparedStatement = con.prepareStatement(getProductIDQuery)) {
                preparedStatement.setString(1, productName);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        return resultSet.getInt("Product_ID");
                    }
                }
            }
            return -1; // Return -1 if no Product_ID is found for the given product name
}

private int getProductQuantity(int productId, Connection con) throws SQLException {
    String getProductQuantityQuery = "SELECT quantity FROM PRODUCT WHERE ID = ?";
    try (PreparedStatement preparedStatement = con.prepareStatement(getProductQuantityQuery)) {
        preparedStatement.setInt(1, productId);
        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            if (resultSet.next()) {
                return resultSet.getInt("quantity");
            }
        }
    }
    return -1; // Return -1 if no quantity is found for the given product ID
}

    private void updateProductQuantity(int productId, int quantityChange, Connection con) throws SQLException {
        String updateProductQuantityQuery = "UPDATE PRODUCT SET Quantity = Quantity + ? WHERE ID = ?";
        try (PreparedStatement updateProductStmt = con.prepareStatement(updateProductQuantityQuery)) {
            updateProductStmt.setInt(1, quantityChange);
            updateProductStmt.setInt(2, productId);
            updateProductStmt.executeUpdate();
        }
    }

    private int getSupplierIdFromSupplierName(String Name, Connection con) throws SQLException {
    String getSupplierIdQuery = "SELECT ID FROM SUPPLIER WHERE Supplier_Name = ?";
    try (PreparedStatement preparedStatement = con.prepareStatement(getSupplierIdQuery)) {
        preparedStatement.setString(1, Name);
        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            if (resultSet.next()) {
                return resultSet.getInt("ID");
            }
        }
    }
    return -1; // Return -1 if no Supplier_ID is found for the given supplier name
}

    @Override
protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    PrintWriter out = response.getWriter();
    try (Connection con = Dbconnection.connect()) {

        String getproduct = "SELECT  p.Invoice_No,p.Cost_Price,p.Quantity,p.Amount,s.Name,pr.Product_Name FROM " +
                                            " purchase p " +
                                            "JOIN" +
                                            " supplier s ON p.Supplier_ID = s.ID\n" +
                                            "JOIN" +
                                            " product pr ON p.Product_ID = pr.ID;";
        PreparedStatement stmt = con.prepareStatement(getproduct);
        ResultSet rs = stmt.executeQuery();
        JSONArray json = new JSONArray();
        ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();

        while (rs.next()) {
            int numColumns = rsmd.getColumnCount();
            JSONObject obj = new JSONObject();

            for (int i = 1; i <= numColumns; i++) {
                String column_name = rsmd.getColumnName(i);
                if (rsmd.getColumnType(i) == java.sql.Types.ARRAY) {
                    obj.put(column_name, rs.getArray(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.BIGINT) {
                    obj.put(column_name, rs.getInt(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.BOOLEAN) {
                    obj.put(column_name, rs.getBoolean(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.BLOB) {
                    obj.put(column_name, rs.getBlob(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.DOUBLE) {
                    obj.put(column_name, rs.getDouble(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.FLOAT) {
                    obj.put(column_name, rs.getFloat(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.INTEGER) {
                    obj.put(column_name, rs.getInt(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.NVARCHAR) {
                    obj.put(column_name, rs.getNString(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.VARCHAR) {
                    obj.put(column_name, rs.getString(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.TINYINT) {
                    obj.put(column_name, rs.getInt(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.SMALLINT) {
                    obj.put(column_name, rs.getInt(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.DATE) {
                    obj.put(column_name, rs.getDate(column_name));
                } else if (rsmd.getColumnType(i) == java.sql.Types.TIMESTAMP) {
                    obj.put(column_name, rs.getTimestamp(column_name));
                } else {
                    obj.put(column_name, rs.getObject(column_name));
                }
            }
            json.put(obj);
        }
        // Setting the response content type to JSON
        response.setContentType("application/json");
        out.println(json.toString());

    } catch (Exception e) {
        out.println(e);
    }
}

@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    response.setContentType("application/json");
    response.setCharacterEncoding("UTF-8");
    PrintWriter out = response.getWriter();

    JsonResponse jsonResponse = new JsonResponse();

    try (Connection con = Dbconnection.connect()) {
        // Read the JSON data from the request input stream
        BufferedReader reader = request.getReader();
        StringBuilder jsonData = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonData.append(line);
        }
        
        // Parse the JSON data
        JsonObject jsonObject = new JsonParser().parse(jsonData.toString()).getAsJsonObject();

       int supplierId = jsonObject.get("Supplier_ID").getAsInt();
        int productId = jsonObject.get("Product_ID").getAsInt();
        String invoiceNo = jsonObject.get("Invoice_No").getAsString();
        int quantity = jsonObject.get("Quantity").getAsInt();
        float costPrice = jsonObject.get("Cost_Price").getAsFloat();
        float amount = jsonObject.get("Amount").getAsFloat(); 
        
       
       String insertPurchase = "INSERT INTO PURCHASE (Supplier_ID, Product_ID, Invoice_No, Quantity, Cost_Price, Amount, Date) " +
        "VALUES (?, ?, ?, ?, ?, ?, CURRENT_DATE)";

        PreparedStatement stmt = con.prepareStatement(insertPurchase);
        stmt.setInt(1, supplierId);
        stmt.setInt(2, productId);
        stmt.setString(3, invoiceNo);
        stmt.setInt(4, quantity);
        stmt.setFloat(5, costPrice);
        stmt.setFloat(6, amount);

        int count = stmt.executeUpdate();

        if (count > 0) {
            jsonResponse.setStatus(true);
            jsonResponse.setMessage("Purchase Record Inserted");
        } else {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("Oops, there is an error inserting the purchase record...");
        }
        
        // Update product quantity
        int updatedQuantity = getProductQuantity(productId, con) + quantity;
        updateProductQuantity(productId, updatedQuantity, con);

    } catch (Exception e) {
        jsonResponse.setStatus(false);
        jsonResponse.setMessage("Error: " + e.getMessage());
    }
    out.println(new Gson().toJson(jsonResponse));
}


@Override
protected void doPut(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    response.setContentType("application/json");
    response.setCharacterEncoding("UTF-8");
    PrintWriter out = response.getWriter();

    JsonResponse jsonResponse = new JsonResponse();

    try (Connection con = Dbconnection.connect()) {
        // Read the JSON data from the request input stream
        BufferedReader reader = request.getReader();
        StringBuilder jsonData = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonData.append(line);
        }

        // Parse the JSON data
        JsonObject jsonObject = new JsonParser().parse(jsonData.toString()).getAsJsonObject();

        int purchaseId = jsonObject.get("ID").getAsInt();
        int supplierId = jsonObject.get("Supplier_ID").getAsInt();
        int productId = jsonObject.get("Product_ID").getAsInt();
        String invoiceNo = jsonObject.get("Invoice_No").getAsString();
        int newQuantity = jsonObject.get("Quantity").getAsInt(); // Updated quantity
        float costPrice = jsonObject.get("Cost_Price").getAsFloat();
        float amount = jsonObject.get("Amount").getAsFloat();

        // Fetch the old quantity of the purchase
        String selectQuantityQuery = "SELECT Quantity FROM PURCHASE WHERE ID=?";
        PreparedStatement selectStmt = con.prepareStatement(selectQuantityQuery);
        selectStmt.setInt(1, purchaseId);
        ResultSet rs = selectStmt.executeQuery();

        int oldQuantity = 0;
        if (rs.next()) {
            oldQuantity = rs.getInt("Quantity");
        } else {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("Purchase Record not found.");
            out.println(new Gson().toJson(jsonResponse));
            return;
        }

        // Calculate the quantity change
        int quantityChange = newQuantity - oldQuantity;

        // Update the purchase record
        String updateQuery = "UPDATE PURCHASE SET Supplier_ID=?, Product_ID=?, Invoice_No=?, " +
                "Quantity=?, Cost_Price=?, Amount=? WHERE ID=?";
        PreparedStatement stmt = con.prepareStatement(updateQuery);
        stmt.setInt(1, supplierId);
        stmt.setInt(2, productId);
        stmt.setString(3, invoiceNo);
        stmt.setInt(4, newQuantity);
        stmt.setFloat(5, costPrice);
        stmt.setFloat(6, amount);
        stmt.setInt(7, purchaseId);

        int check = stmt.executeUpdate();

        if (check > 0) {
            // Update the product quantity based on the quantity change
            String updateProductQuantityQuery = "UPDATE PRODUCT SET Quantity = Quantity ";
            
            // Check if the old quantity is greater or less than the new quantity
            if (oldQuantity > newQuantity) {
                // Subtract from product's quantity
                updateProductQuantityQuery += "- ?";
            } else if (oldQuantity < newQuantity) {
                // Add to product's quantity
                updateProductQuantityQuery += "+ ?";
            } else {
                // No change in quantity
                updateProductQuantityQuery += "+ 0";
            }

            updateProductQuantityQuery += " WHERE ID = ?";
            PreparedStatement updateProductStmt = con.prepareStatement(updateProductQuantityQuery);

            updateProductStmt.setInt(1, Math.abs(quantityChange)); // Use absolute value to ensure it's positive
            updateProductStmt.setInt(2, productId);
            updateProductStmt.executeUpdate();

            jsonResponse.setStatus(true);
            jsonResponse.setMessage("Purchase Record Updated.");
        } else {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("Error In Updating Purchase Record.");
        }

    } catch (IOException | NumberFormatException | SQLException e) {
        jsonResponse.setStatus(false);
        jsonResponse.setMessage("Error: " + e.getMessage());
    }

    out.println(new Gson().toJson(jsonResponse));
}



    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        JsonResponse jsonResponse = new JsonResponse();

        try (Connection con = Dbconnection.connect()) {
            // Read the JSON data from the request input stream
            BufferedReader reader = request.getReader();
            StringBuilder jsonData = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                jsonData.append(line);
            }

            // Parse the JSON data
            JsonObject jsonObject = new JsonParser().parse(jsonData.toString()).getAsJsonObject();

            int purchaseId = jsonObject.get("ID").getAsInt();

            String deleteQuery = "DELETE FROM PURCHASE WHERE ID = ?";
            PreparedStatement stmt = con.prepareStatement(deleteQuery);
            stmt.setInt(1, purchaseId);

            int check = stmt.executeUpdate();

            if (check > 0) {
                jsonResponse.setStatus(true);
                jsonResponse.setMessage("Purchase Record Removed.");
            } else {
                jsonResponse.setStatus(false);
                jsonResponse.setMessage("Error In deleting Purchase Record.");
            }

        } catch (NumberFormatException | SQLException e) {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("Error: " + e.getMessage());
            e.printStackTrace(); // Print the exception details
        }

        out.println(new Gson().toJson(jsonResponse));
    }






@Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
