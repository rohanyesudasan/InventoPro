
import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DownloadPdf")
public class DownloadPdfServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the file path from the request parameter
        String filePath = request.getParameter("filePath");

        // Set the content type to PDF
        response.setContentType("application/pdf");

        // Set the content disposition to trigger a download
        response.setHeader("Content-Disposition", "attachment; filename=yourfile.pdf");

        try (InputStream inputStream = new FileInputStream(filePath);
             OutputStream outputStream = response.getOutputStream()) {
            byte[] buffer = new byte[4096];
            int bytesRead = -1;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            e.printStackTrace();
            response.getWriter().println("Error: Failed to download the PDF.");
        }
    }
}
