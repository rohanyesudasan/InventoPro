import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import com.google.gson.*;
import java.io.BufferedReader;
import javax.servlet.annotation.WebServlet;

@WebServlet(name = "demo", urlPatterns = {"/signup"})

public class user extends HttpServlet {

//@Override
//protected void doGet(HttpServletRequest request, HttpServletResponse response)
//        throws ServletException, IOException {
//    response.setContentType("application/json");
//    response.setCharacterEncoding("UTF-8");
//
//    JsonResponse jsonResponse = new JsonResponse();
//    PrintWriter out = response.getWriter();
//
//    try (Connection con = Dbconnection.connect()) {
//        // Read JSON data from the request's input stream
//        BufferedReader reader = request.getReader();
//        StringBuilder jsonRequest = new StringBuilder();
//        String line;
//        while ((line = reader.readLine()) != null) {
//            jsonRequest.append(line);
//        }
//
//        // Parse the JSON data
//        JsonObject jsonObject = new JsonParser().parse(jsonRequest.toString()).getAsJsonObject();
//        String name = jsonObject.get("Name").getAsString();
//        String password = jsonObject.get("Password").getAsString();
//
//        String sql = "SELECT * FROM users WHERE Name = ? AND Password = ?";
//        PreparedStatement stmt = con.prepareStatement(sql);
//        stmt.setString(1, name);
//        stmt.setString(2, password);
//        ResultSet resultSet = stmt.executeQuery();
//        if (resultSet.next()) {
//            jsonResponse.setStatus(true);
//            jsonResponse.setMessage("Logged in " + name);
//            String id = resultSet.getString("ID");
//
//        } else {
//            jsonResponse.setStatus(false);
//            jsonResponse.setMessage("Wrong Username or Password");
//        }
//    } catch (SQLException e) {
//        jsonResponse.setStatus(false);
//        jsonResponse.setMessage("Error: " + e.getMessage());
//        out.println(e);
//    }
//
//    out.println(new Gson().toJson(jsonResponse));
//}

    
    @Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    response.setContentType("application/json");
    response.setCharacterEncoding("UTF-8");

    JsonResponse jsonResponse = new JsonResponse();

    try (Connection con = Dbconnection.connect()) {
        BufferedReader reader = request.getReader();
        StringBuilder jsonRequest = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonRequest.append(line);
        }

        JsonObject jsonObject = new JsonParser().parse(jsonRequest.toString()).getAsJsonObject();
        String Name = jsonObject.get("Name").getAsString();
        String Email = jsonObject.get("Email").getAsString();
        String Phone_Number = jsonObject.get("Phone_Number").getAsString();
        String Password = jsonObject.get("Password").getAsString();
        String Type = jsonObject.get("Type").getAsString();

        // Check if the phone number is already used
        if (isPhoneNumberUsed(con, Phone_Number)) {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("Phone number is already registered.");
        } else {
            String sql = "INSERT INTO users (Name, Email, Password, Phone_Number, Type) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, Name);
            stmt.setString(2, Email);
            stmt.setString(3, Password);
            stmt.setString(4, Phone_Number);
            stmt.setString(5, Type);

            int count = stmt.executeUpdate();

            if (count > 0) {
                jsonResponse.setStatus(true);
                jsonResponse.setMessage("User Registered");
            } else {
                jsonResponse.setStatus(false);
                jsonResponse.setMessage("NOT REGISTERED");
            }
        }
    } catch (Exception e) {
        jsonResponse.setStatus(false);
        jsonResponse.setMessage("Error: " + e.getMessage());
    }

    PrintWriter out = response.getWriter();
    out.println(new Gson().toJson(jsonResponse));
}

    
    @Override
protected void doPut(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    response.setContentType("application/json");
    response.setCharacterEncoding("UTF-8");
    JsonResponse jsonResponse = new JsonResponse();

    try (Connection con = Dbconnection.connect()) {
        BufferedReader reader = request.getReader();
        StringBuilder jsonRequest = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonRequest.append(line);
        }

        JsonObject jsonObject = new JsonParser().parse(jsonRequest.toString()).getAsJsonObject();
        int ID = jsonObject.get("ID").getAsInt();
        String Name = jsonObject.get("Name").getAsString();
        String Email = jsonObject.get("Email").getAsString();
        String Password = jsonObject.get("Password").getAsString();
        String Phone_Number = jsonObject.get("Phone_Number").getAsString();
        String Type = jsonObject.get("Type").getAsString();

        // Check if the phone number is already used by another user
        if (isPhoneNumberUsed(con, Phone_Number)) {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("Phone number is already registered.");
        } else {
            String updateProfile = "UPDATE users SET Name = ?, Email = ?, Password = ?, Phone_Number = ?, Type = ? WHERE ID = ?";
            PreparedStatement stmt = con.prepareStatement(updateProfile);
            stmt.setString(1, Name);
            stmt.setString(2, Email);
            stmt.setString(3, Password);
            stmt.setString(4, Phone_Number);
            stmt.setString(5, Type);
            stmt.setInt(6, ID);
            int check = stmt.executeUpdate();

            if (check > 0) {
                jsonResponse.setStatus(true);
                jsonResponse.setMessage("Profile Updated.");
            } else {
                jsonResponse.setStatus(false);
                jsonResponse.setMessage("Error In Updating Profile.");
            }
        }
    } catch (Exception e) {
        jsonResponse.setStatus(false);
        jsonResponse.setMessage("Error: " + e.getMessage());
    }

    PrintWriter out = response.getWriter();
    out.println(new Gson().toJson(jsonResponse));
}

@Override
protected void doDelete(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException 
{
    PrintWriter out = response.getWriter();
    JsonResponse jsonResponse = new JsonResponse();

    try {
        BufferedReader reader = request.getReader();
        StringBuilder jsonRequest = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonRequest.append(line);
        }

        JsonObject jsonObject = new JsonParser().parse(jsonRequest.toString()).getAsJsonObject();
        String ID = jsonObject.get("ID").getAsString();

        Connection con = Dbconnection.connect();
        String deleteProfile = "DELETE FROM users WHERE ID = ?";
        PreparedStatement stmt = con.prepareStatement(deleteProfile);
        stmt.setString(1, ID);

        int check = stmt.executeUpdate();

        if (check > 0) {
            jsonResponse.setStatus(true);
            jsonResponse.setMessage("Profile Removed.");
        } else {
            jsonResponse.setStatus(false);
            jsonResponse.setMessage("Error In Deleting Profile.");
        }
    } catch (IOException | SQLException e) {
        out.println(e);
    }
    out.println(new Gson().toJson(jsonResponse));
}

private boolean isPhoneNumberUsed(Connection con, String phoneNumber) throws SQLException {
    String sql = "SELECT COUNT(*) AS count FROM users WHERE Phone_Number = ?";
    PreparedStatement stmt = con.prepareStatement(sql);
    stmt.setString(1, phoneNumber);
    ResultSet resultSet = stmt.executeQuery();
    if (resultSet.next()) {
        int count = resultSet.getInt("count");
        return count > 0;
    }
    return false;
}

}